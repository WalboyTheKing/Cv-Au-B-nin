/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import type { Plan, TemplateDefinition, TemplateCategory } from '../types/index.ts';

export const MOOV_MONEY_BENEFICIARY = {
  beneficiaryName: 'Waaliyou Z Labouda',
  operator: 'Moov Money Bénin',
  operatorCode: 'moov_money',
  phoneNumber: '0194537741',
  formattedPhone: '01 94 53 77 41',
  internationalPhone: '+229 01 94 53 77 41',
  ussdCode: '*855#',
  currency: 'FCFA',
  currencyCode: 'XOF',
  instructions: [
    'Composez *855# sur votre téléphone Moov Money ou ouvrez votre application Moov Money Bénin.',
    'Choisissez l’option "Transfert d’argent" vers un numéro Moov Bénin.',
    'Saisissez le numéro bénéficiaire : 0194537741.',
    'Vérifiez le nom qui s’affiche : Waaliyou Z Labouda.',
    'Indiquez le montant exact en FCFA correspondant à l’offre choisie.',
    'Confirmez avec votre code secret Mobile Money confidentiel.',
    'Conservez le SMS de confirmation contenant la référence de la transaction pour renseigner le formulaire de déclaration.'
  ]
};

export const APP_CONFIG = {
  brandName: 'CV Pro Bénin',
  tagline: 'Créez un CV professionnel qui ouvre des portes au Bénin',
  description: 'Réalisez votre CV en quelques minutes, personnalisez votre présentation et téléchargez un document prêt à accompagner vos candidatures. Une solution pensée pour les talents du Bénin.',
  currency: 'FCFA',
  currencyCode: 'XOF',
  country: 'Bénin',
  countryCode: 'BJ',
  phonePrefix: '+229',
  contactEmail: 'contact@cvprobenin.bj',
  supportPhone: '+229 01 94 53 77 41',
  storageKeyPrefix: 'cvprobenin_',
  allowedPaymentCountry: 'BJ',
  moovBeneficiary: MOOV_MONEY_BENEFICIARY,
  paymentProviders: [
    {
      id: 'moov_money',
      name: 'Moov Money Bénin (Transfert direct)',
      beneficiary: MOOV_MONEY_BENEFICIARY.beneficiaryName,
      number: MOOV_MONEY_BENEFICIARY.phoneNumber,
      ussdCode: MOOV_MONEY_BENEFICIARY.ussdCode,
      badgeColor: '#005baa',
      description: 'Transfert direct vers Waaliyou Z Labouda au 0194537741 avec validation administrative.'
    }
  ]
};

export const INITIAL_PLANS: Plan[] = [
  {
    id: 'plan_free',
    name: 'Formule Découverte',
    code: 'free',
    priceXOF: 0,
    durationDays: 365,
    description: 'Concevez et modifiez jusqu’à 5 CV gratuitement en permanence. Les exports PDF comportent un filigrane.',
    features: [
      'Création et modification de 5 CV maximum',
      'Sauvegarde automatique dans votre compte',
      'Accès aux modèles essentiels et ATS',
      'Prévisualisation haute fidélité A4 en temps réel',
      'Export PDF avec filigrane standard',
      'Données conservées en permanence (jamais supprimées)'
    ],
    quotas: {
      maxCVs: 5,
      allowWatermarkRemoval: false,
      allowPremiumTemplates: false,
      allowAIWriting: false,
      allowDocxExport: false
    },
    isActive: true
  },
  {
    id: 'plan_cand_24h',
    name: 'Accès Candidature',
    code: 'cand_24h',
    priceXOF: 500,
    durationDays: 1,
    durationHours: 24,
    description: '500 FCFA pour 1 CV précis — 24 heures d’accès (calculées côté serveur) aux 15 modèles, IA et exports PDF sans filigrane.',
    features: [
      'Valable 24h pour 1 CV spécifique choisi',
      'Délai de 24 heures calculé côté serveur dès approbation',
      'Téléchargement PDF haute résolution sans filigrane',
      'Accès aux 15 modèles professionnels & compatibles ATS',
      'Assistant IA & Analyse d’offre d’emploi pendant 24h',
      'Conservation intégrale du CV après expiration (jusqu’à 5 CV au compte)'
    ],
    quotas: {
      maxCVs: 5,
      allowWatermarkRemoval: true,
      allowPremiumTemplates: true,
      allowAIWriting: true,
      allowDocxExport: true
    },
    isActive: true
  },
  {
    id: 'plan_career_30d',
    name: 'Pack Carrière',
    code: 'career_30d',
    priceXOF: 1000,
    durationDays: 30,
    durationHours: 720,
    description: '1 000 FCFA pour 1 CV précis — 30 jours d’accès complet aux 15 modèles, IA avancée et exports PDF sans filigrane.',
    features: [
      'Valable 30 jours pour le CV choisi (jusqu’à 15 CV archivés)',
      'Délai de 30 jours calculé côté serveur dès validation',
      'Téléchargements illimités de PDF sans aucun filigrane',
      'Tous les 15 modèles professionnels & compatibles ATS',
      'Assistant IA, score de qualité & lettre de motivation',
      'Conservation intégrale du CV et historique après 30 jours'
    ],
    quotas: {
      maxCVs: 15,
      allowWatermarkRemoval: true,
      allowPremiumTemplates: true,
      allowAIWriting: true,
      allowDocxExport: true
    },
    isActive: true
  }
];

export const TEMPLATE_CATEGORIES: { id: TemplateCategory; label: string; count: number }[] = [
  { id: 'tous', label: 'Tous les modèles', count: 15 },
  { id: 'classique', label: 'Classique', count: 2 },
  { id: 'moderne', label: 'Moderne', count: 2 },
  { id: 'professionnel', label: 'Professionnel', count: 3 },
  { id: 'minimaliste', label: 'Minimaliste', count: 1 },
  { id: 'elegant', label: 'Élégant', count: 2 },
  { id: 'creatif', label: 'Créatif', count: 1 },
  { id: 'academique', label: 'Académique', count: 3 },
  { id: 'ats', label: 'ATS / Recrutement', count: 1 }
];

export const CV_TEMPLATES: TemplateDefinition[] = [
  {
    id: 'classique',
    name: 'Classique Institutionnel',
    slug: 'classique',
    description: 'Mise en page sobre et conventionnelle, idéale pour les concours administratifs, banques et ministères.',
    category: 'classique',
    styleLabel: 'Classique',
    characteristics: ['1 colonne sobre', 'Idéal concours', 'Banques & Ministères', 'Lisibilité maximale'],
    isPremium: false,
    isActive: true,
    defaultColor: '#1e3a8a', // Bleu marine
    recommendedFor: ['Administration', 'Banque', 'Enseignement', 'Concours'],
    layoutType: 'single-col'
  },
  {
    id: 'moderne',
    name: 'Moderne Dynamique',
    slug: 'moderne',
    description: 'Bandeau latéral coloré élégant avec mise en relief des coordonnées, compétences et langues.',
    category: 'moderne',
    styleLabel: 'Moderne',
    characteristics: ['Bandeau latéral gauche', 'Avec photo', '2 colonnes équilibrées', 'Polyvalent'],
    isPremium: false,
    isActive: true,
    defaultColor: '#047857', // Vert émeraude
    recommendedFor: ['Commerce', 'Communication', 'Management', 'Tertiaire'],
    layoutType: 'two-col-left'
  },
  {
    id: 'minimaliste',
    name: 'Minimaliste Épuré',
    slug: 'minimaliste',
    description: 'Design aéré focalisé sur la lisibilité des textes et l’impact direct des compétences.',
    category: 'minimaliste',
    styleLabel: 'Minimaliste',
    characteristics: ['Typographie épurée', 'Aéré & direct', 'Lignes de séparation fines', 'Consulting & ONG'],
    isPremium: false,
    isActive: true,
    defaultColor: '#334155', // Ardoise
    recommendedFor: ['Consulting', 'Juridique', 'Santé', 'ONG'],
    layoutType: 'single-col'
  },
  {
    id: 'premier_emploi',
    name: 'Premier Emploi Tremplin',
    slug: 'premier-emploi',
    description: 'Spécialement agencé pour mettre en valeur les compétences et projets des jeunes diplômés.',
    category: 'moderne',
    styleLabel: 'Moderne',
    characteristics: ['Compétences en tête', 'Mise en valeur projets', 'Idéal débutants', 'Structure dynamique'],
    isPremium: false,
    isActive: true,
    defaultColor: '#0284c7', // Bleu ciel
    recommendedFor: ['Nouveaux diplômés', 'Assistants débutants', 'Techniciens juniors'],
    layoutType: 'two-col-left'
  },
  {
    id: 'etudiant',
    name: 'Étudiant & Stage Académique',
    slug: 'etudiant',
    description: 'Priorise le parcours académique, les mentions, stages et engagements associatifs.',
    category: 'academique',
    styleLabel: 'Académique',
    characteristics: ['Diplômes en premier', 'Mentions valorisées', 'Stages universitaires', 'Idéal UAC & UP'],
    isPremium: false,
    isActive: true,
    defaultColor: '#4f46e5', // Indigo
    recommendedFor: ['Étudiants UAC/UP', 'Recherche de stage académique ou professionnel'],
    layoutType: 'top-header'
  },
  {
    id: 'technicien',
    name: 'Technicien & Opérations',
    slug: 'technicien',
    description: 'Structure technique rigoureuse mettant en lumière les habilitations, outillages et maintenance.',
    category: 'professionnel',
    styleLabel: 'Professionnel',
    characteristics: ['Colonne droite outillages', 'Habilitations sécurité', 'BTP & Télécoms', 'Rigueur terrain'],
    isPremium: true,
    isActive: true,
    defaultColor: '#ea580c', // Orange industriel
    recommendedFor: ['Électrotechnique', 'BTP', 'Télécoms', 'Génie civil', 'Mécanique'],
    layoutType: 'two-col-right'
  },
  {
    id: 'informatique',
    name: 'Tech & Développeur Web',
    slug: 'informatique',
    description: 'Style épuré haute lisibilité avec section GitHub/Portfolio et tags de langages et frameworks.',
    category: 'creatif',
    styleLabel: 'Créatif',
    characteristics: ['Header dark tech', 'Tags stack technique', 'GitHub & Portfolio', 'Dev & Data'],
    isPremium: true,
    isActive: true,
    defaultColor: '#0f172a', // Noir tech
    recommendedFor: ['Développeur Full-Stack', 'Data Analyst', 'Administrateur Systèmes', 'Cybersécurité'],
    layoutType: 'two-col-left'
  },
  {
    id: 'commercial',
    name: 'Commercial & Vente',
    slug: 'commercial',
    description: 'Design percutant axé sur les résultats chiffrés, le sens du relationnel et la négociation.',
    category: 'elegant',
    styleLabel: 'Élégant',
    characteristics: ['Résultats chiffrés / KPIs', 'Bannière haute percutante', 'Prospection terrain', 'Énergique'],
    isPremium: true,
    isActive: true,
    defaultColor: '#b91c1c', // Rouge vif énergique
    recommendedFor: ['Attaché commercial', 'Responsable grands comptes', 'Marketing terrain'],
    layoutType: 'top-header'
  },
  {
    id: 'comptabilite',
    name: 'Comptabilité & Finance',
    slug: 'comptabilite',
    description: 'Rigueur visuelle absolue, équilibre des colonnes et clarté des déclarations fiscales et d’audit.',
    category: 'professionnel',
    styleLabel: 'Professionnel',
    characteristics: ['Conforme SYSCOHADA', 'Encadrement rigoureux', 'Fiscalité DGI & CNSS', 'Double colonne nette'],
    isPremium: true,
    isActive: true,
    defaultColor: '#0f766e', // Sarcelle
    recommendedFor: ['Comptable', 'Auditeur interne', 'Gestionnaire de paie', 'Directeur financier'],
    layoutType: 'two-col-left'
  },
  {
    id: 'enseignant',
    name: 'Enseignant & Pédagogue',
    slug: 'enseignant',
    description: 'Présentation académique noble adaptée aux lycées, collèges, universités et centres de formation.',
    category: 'academique',
    styleLabel: 'Académique',
    characteristics: ['Style universitaire noble', 'Publications & Formations', '1 colonne lisible', 'Professeurs & Formateurs'],
    isPremium: true,
    isActive: true,
    defaultColor: '#4338ca', // Indigo profond
    recommendedFor: ['Professeurs certifiés', 'Formateurs', 'Éducateurs', 'Chercheurs'],
    layoutType: 'single-col'
  },
  {
    id: 'management',
    name: 'Executive & Management',
    slug: 'management',
    description: 'Format haut de gamme reflétant le leadership, la gestion d’équipes et la stratégie d’entreprise.',
    category: 'elegant',
    styleLabel: 'Élégant',
    characteristics: ['Prestige & Leadership', 'Projets stratégiques', 'Gestion d\'équipes', 'Cadres dirigeants'],
    isPremium: true,
    isActive: true,
    defaultColor: '#1e293b', // Anthracite
    recommendedFor: ['Directeur général', 'Chef de projet', 'Coordonnateur de programmes'],
    layoutType: 'top-header'
  },
  {
    id: 'sans_photo',
    name: 'International ATS (Sans Photo)',
    slug: 'sans-photo',
    description: 'Conforme aux standards internationaux et aux filtres ATS, maximisant vos chances pour les ONG et multinationales.',
    category: 'ats',
    styleLabel: 'ATS / Recrutement',
    characteristics: ['100% optimisé ATS', 'Sans photo', 'Standards ONG & ONU', 'Format international'],
    isPremium: true,
    isActive: true,
    defaultColor: '#27272a', // Neutre zinc
    recommendedFor: ['Organisations Internationales', 'Nations Unies', 'Postes à distance'],
    layoutType: 'single-col'
  },
  {
    id: 'stage',
    name: 'Stage Pro Perfectionnement',
    slug: 'stage',
    description: 'Idéal pour candidater à un stage d’insertion ou de fin de cycle au Bénin.',
    category: 'academique',
    styleLabel: 'Académique',
    characteristics: ['Stage d\'insertion', 'Disponibilité immédiate', 'Formations pratiques', 'Fin de cycle'],
    isPremium: true,
    isActive: true,
    defaultColor: '#059669', // Vert menthe
    recommendedFor: ['Stagiaires', 'Alternants', 'Volontaires'],
    layoutType: 'two-col-left'
  },
  {
    id: 'administratif',
    name: 'Secrétariat & Administration',
    slug: 'administratif',
    description: 'Structure organisée valorisant l’accueil, la rédaction administrative et l’organisation bureautique.',
    category: 'professionnel',
    styleLabel: 'Professionnel',
    characteristics: ['Organisation bureautique', 'Accueil & Rédaction', 'Barre latérale claire', 'Secrétariat de direction'],
    isPremium: true,
    isActive: true,
    defaultColor: '#7c3aed', // Violet moderne
    recommendedFor: ['Secrétaire de direction', 'Assistant administratif', 'Agent d’accueil'],
    layoutType: 'two-col-right'
  },
  {
    id: 'professionnel',
    name: 'Expert Chronologique',
    slug: 'professionnel',
    description: 'Chronologie inverse détaillée avec mise en exergue des responsabilités majeures.',
    category: 'classique',
    styleLabel: 'Classique',
    characteristics: ['Chronologie inverse stricte', 'Missions d\'envergure', 'Cadres confirmés', 'Sobriété élégante'],
    isPremium: true,
    isActive: true,
    defaultColor: '#374151', // Gris acier
    recommendedFor: ['Cadres supérieurs', 'Ingénieurs d’affaires', 'Consultants seniors'],
    layoutType: 'single-col'
  }
];

export const BENIN_CITIES = [
  'Cotonou',
  'Abomey-Calavi',
  'Porto-Novo',
  'Parakou',
  'Bohicon',
  'Ouidah',
  'Natitingou',
  'Djougou',
  'Kandi',
  'Lokossa',
  'Allada',
  'Dassa-Zoumè',
  'Comè',
  'Savalou',
  'Pobè',
  'Malanville',
  'Aplahoué',
  'Grand-Popo',
  'Tanguiéta',
  'Bembèrèkè'
];

export const BENIN_INSTITUTIONS = [
  "Université d'Abomey-Calavi (UAC)",
  "Université de Parakou (UP)",
  "École Nationale d'Économie Appliquée et de Management (ENEAM - UAC)",
  "Institut de Formation et de Recherche en Informatique (IFRI - UAC)",
  "École Polytechnique d'Abomey-Calavi (EPAC - UAC)",
  "Faculté des Sciences Économiques et de Gestion (FASEG - UAC)",
  "Faculté des Lettres, Langues, Arts et Communication (FLLAC - UAC)",
  "Faculté de Droit et de Science Politique (FADESP - UAC)",
  "Faculté des Sciences et Techniques (FAST - UAC)",
  "Faculté des Sciences de la Santé (FSS - Cotonou)",
  "Institut National de la Jeunesse, de l'Éducation Physique et du Sport (INJEPS)",
  "Institut Régional de Santé Publique (IRSP - Ouidah)",
  "Pigier Bénin",
  "Haute École de Commerce et de Management (HECM)",
  "École Supérieure de Management (ESM Bénin)",
  "UATM Gasa Formation",
  "Institut Cerco Bénin",
  "Lycée Technique F. Coulibaly (Cotonou)",
  "Lycée Technique Commercial de Porto-Novo",
  "École Nationale d'Administration et de Magistrature (ENAM)"
];

export const SUGGESTED_SKILLS = [
  // Bureautique
  { name: 'Microsoft Word & Excel avancé', category: 'bureautique' as const },
  { name: 'PowerPoint & présentations percutantes', category: 'bureautique' as const },
  { name: 'Google Workspace (Docs, Sheets, Drive)', category: 'bureautique' as const },
  { name: 'Rédaction administrative & comptes-rendus', category: 'bureautique' as const },
  { name: 'Archivage numérique & classement', category: 'bureautique' as const },

  // Dev Web & Informatique
  { name: 'JavaScript / TypeScript', category: 'dev_web' as const },
  { name: 'React.js & Next.js', category: 'dev_web' as const },
  { name: 'PHP / Laravel', category: 'dev_web' as const },
  { name: 'Python & Django', category: 'dev_web' as const },
  { name: 'Bases de données SQL (MySQL, PostgreSQL)', category: 'informatique' as const },
  { name: 'Maintenance informatique & dépannage réseau', category: 'maintenance' as const },
  { name: 'Configuration routeurs & Wi-Fi professionnel', category: 'maintenance' as const },
  { name: 'Cybersécurité & protection des données', category: 'informatique' as const },

  // Gestion & Finance
  { name: 'Comptabilité générale (SYSCOHADA révisé)', category: 'gestion' as const },
  { name: 'Déclarations fiscales béninoises (DGI Bénin, e-Services)', category: 'gestion' as const },
  { name: 'Déclarations sociales CNSS Bénin', category: 'gestion' as const },
  { name: 'Logiciels comptables (Sage Saari, Odoo)', category: 'gestion' as const },
  { name: 'Gestion de trésorerie & rapprochement bancaire', category: 'gestion' as const },
  { name: 'Contrôle de gestion & tableaux de bord', category: 'gestion' as const },

  // Vente & Commerce
  { name: 'Prospection commerciale terrain & B2B', category: 'vente' as const },
  { name: 'Négociation & conclusion des ventes', category: 'vente' as const },
  { name: 'Gestion de la relation client (CRM)', category: 'vente' as const },
  { name: 'Marketing digital & Community Management', category: 'vente' as const },

  // Transverse
  { name: 'Travail en équipe & sens de l’écoute', category: 'transverse' as const },
  { name: 'Organisation rigoureuse & gestion des priorités', category: 'transverse' as const },
  { name: 'Résolution méthodique de problèmes', category: 'transverse' as const },
  { name: 'Ponctualité & esprit d’initiative', category: 'transverse' as const }
];

export const PROFILE_SUMMARIES_EXAMPLES = [
  {
    role: 'Développeur Web & Mobile',
    text: "Développeur passionné et rigoureux, titulaire d'une licence en génie logiciel de l'IFRI - UAC. Fort d'une expérience concrète dans la conception d'applications web réactives avec React, Node.js et bases de données SQL. Motivé par l'innovation technologique et le travail d'équipe agile pour apporter des solutions fiables et évolutives."
  },
  {
    role: 'Comptable / Gestionnaire Financier',
    text: "Comptable méthodique justifiant d'une solide maîtrise du référentiel SYSCOHADA révisé et des obligations fiscales béninoises (DGI, CNSS). Expérimenté dans la tenue des journaux, l'établissement des états financiers de synthèse et l'utilisation experte de Sage Saari. Reconnu pour mon intégrité et mon sens du détail."
  },
  {
    role: 'Commercial / Responsable des Ventes',
    text: "Commercial dynamique et orienté résultats avec 4 ans d'expérience dans le développement de portefeuilles clients à Cotonou et dans le sud du Bénin. Rompu à la prospection terrain, à la négociation B2B et au management de points de vente avec un taux d'atteinte d'objectifs supérieur à 110%."
  },
  {
    role: 'Assistant(e) de Direction & Administration',
    text: "Professionnel(le) de l'administration et du secrétariat trilingue (Français, Fon, Anglais) doté(e) d'un grand sens de la discrétion et d'une organisation sans faille. Maîtrise parfaite de la rédaction administrative, de la tenue d'agenda de direction et de l'accueil protocolaire des partenaires d'affaires."
  },
  {
    role: 'Technicien Réseaux & Maintenance Informatique',
    text: "Technicien supérieur en informatique doté d'une expertise reconnue dans le déploiement d'infrastructures locales, le câblage réseau, la sécurité périmétrique et l'assistance aux utilisateurs. Réactif, méthodique et orienté disponibilité des systèmes d'information."
  }
];
